import BannerSection from "../components/Home/BannerSection";

const Home = () => {
  return (
    <div className="space-y-6">
      <BannerSection />
      {/* Tambahan komponen berikutnya nanti */}
    </div>
  );
};

export default Home;
